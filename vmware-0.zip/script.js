/* script.js */
document.getElementById('uploadForm').addEventListener('submit', async function (event) {
    event.preventDefault();
    const fileInput = document.getElementById('fileInput');
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    const responseMessage = document.getElementById('responseMessage');
    responseMessage.textContent = "Uploading...";
    responseMessage.style.color = '#007bff';

    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData,
        });

        const result = await response.json();
        if (response.ok) {
            responseMessage.textContent = "Thank you for using our service! Your image has been uploaded successfully.";
            responseMessage.style.color = 'green';
        } else {
            responseMessage.textContent = result.error;
            responseMessage.style.color = 'red';
        }
    } catch (error) {
        responseMessage.textContent = "An error occurred. Please try again.";
        responseMessage.style.color = 'red';
    }
});
